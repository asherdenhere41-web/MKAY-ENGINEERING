/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import Projects from './components/Projects';
import WhyChooseUs from './components/WhyChooseUs';
import Contact from './components/Contact';
import Footer from './components/Footer';
import SectionDivider from './components/SectionDivider';
import WhatsAppWidget from './components/WhatsAppWidget';

export default function App() {
  useEffect(() => {
    const handleAnchorClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      const anchorNode = target.closest('a');
      
      if (!anchorNode) return;
      
      const href = anchorNode.getAttribute('href');
      if (href && href.startsWith('#') && href.length > 1) {
        e.preventDefault();
        const targetId = href.substring(1);
        const targetElement = document.getElementById(targetId);
        
        if (targetElement) {
          // Dynamic offset depending on active viewport/navbar height
          const navbarOffset = 80;
          const elementPosition = targetElement.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - navbarOffset;
          
          window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
          });

          // Gracefully update the address bar without standard instant jump
          window.history.pushState(null, '', href);
        }
      }
    };

    document.addEventListener('click', handleAnchorClick);
    return () => {
      document.removeEventListener('click', handleAnchorClick);
    };
  }, []);

  return (
    <div id="app-root" className="min-h-screen relative">
      <Navbar />
      <main>
        <Hero />
        <SectionDivider type="gradient" className="bg-brand-charcoal" />
        <About />
        <SectionDivider type="line" />
        <Services />
        <SectionDivider type="pattern" />
        <Projects />
        <SectionDivider type="line" />
        <WhyChooseUs />
        <SectionDivider type="gradient" />
        <Contact />
      </main>
      <Footer />
      <WhatsAppWidget />
    </div>
  );
}

