/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';

export default function About() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.12,
        delayChildren: 0.05,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: [0.215, 0.61, 0.355, 1] },
    },
  };

  return (
    <section id="about" className="bg-white dark:bg-[#0a0d14] overflow-hidden transition-colors duration-300">
      <div className="section-container grid md:grid-cols-2 gap-16 items-center">
        {/* Animated Left Column */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
        >
          <motion.span 
            variants={itemVariants} 
            className="text-brand-steel dark:text-sky-400 font-display font-semibold uppercase tracking-widest text-sm mb-4 block"
          >
            About MKAY Engineering
          </motion.span>
          
          <motion.h2 
            variants={itemVariants} 
            className="text-4xl md:text-5xl font-bold mb-8 leading-tight text-brand-charcoal dark:text-white"
          >
            Zimbabwe's Partner in <br /> Modern Infrastructure
          </motion.h2>
          
          <motion.p 
            variants={itemVariants} 
            className="text-lg text-gray-600 dark:text-slate-300 mb-6 leading-relaxed"
          >
            Founded with a vision to revolutionize the industrial landscape of Zimbabwe, MKAY Engineering
            combines deep technical expertise with a relentless commitment to quality. We don't just build
            structures; we forge the backbone of industry.
          </motion.p>
          
          <motion.div 
            variants={itemVariants} 
            className="grid grid-cols-2 gap-8 mt-10"
          >
            <div>
              <h4 className="text-brand-steel dark:text-sky-400 font-bold text-lg mb-2 italic">Our Mission</h4>
              <p className="text-sm text-gray-500 dark:text-slate-400 leading-relaxed">To provide innovative engineering and fabrication solutions that exceed international standards while empowering local industries.</p>
            </div>
            <div>
              <h4 className="text-brand-steel dark:text-sky-400 font-bold text-lg mb-2 italic">Our Vision</h4>
              <p className="text-sm text-gray-500 dark:text-slate-400 leading-relaxed">To be the leading engineering firm in Southern Africa, recognized for precision, reliability, and transformative impact.</p>
            </div>
          </motion.div>
        </motion.div>

        {/* Coordinated Right Column */}
        <div className="relative">
          {/* Animated Image Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="aspect-square relative overflow-hidden rounded-sm z-10"
          >
            <img 
              src="/src/assets/images/mkay_about_welder_1779371808590.png" 
              alt="MKAY Structural Welder On Site" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            {/* Experience Badge - Slide and fade in separately */}
            <motion.div 
              initial={{ opacity: 0, y: 25 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.4, duration: 0.6, ease: "easeOut" }}
              className="absolute bottom-10 left-10 bg-brand-steel dark:bg-[#10141f] p-6 text-white rounded-sm shadow-xl border dark:border-sky-500/20"
            >
              <span className="text-4xl font-bold block dark:text-sky-400">15+</span>
              <span className="text-xs uppercase tracking-widest font-medium opacity-80 dark:text-slate-300">Years of Experience</span>
            </motion.div>
          </motion.div>
          
          {/* Decorative frame - Animated expansion */}
          <motion.div 
            initial={{ opacity: 0, x: 0, y: 0 }}
            whileInView={{ opacity: 1, x: 24, y: -24 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ delay: 0.2, duration: 0.8, ease: "easeOut" }}
            className="absolute top-0 right-0 w-full h-full border-2 border-brand-steel/10 dark:border-sky-500/15 -z-10 rounded-sm"
          />
        </div>
      </div>
    </section>
  );
}
