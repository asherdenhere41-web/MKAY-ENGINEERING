/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import { motion, useScroll, useMotionValueEvent } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export default function Hero() {
  const { scrollY } = useScroll();
  const [isScrolled, setIsScrolled] = useState(false);

  useMotionValueEvent(scrollY, "change", (latest) => {
    setIsScrolled(latest > 50);
  });

  return (
    <section id="hero" className="relative h-screen w-full flex items-center overflow-hidden bg-white dark:bg-[#0a0d14]">
      {/* Background with new technical image - Light Mode */}
      <div className="absolute inset-0 z-0 opacity-85 block dark:hidden">
        <img 
          src="/src/assets/images/bg_architect_blueprint_1779874197353.png" 
          alt="White Clean Architect and Blueprint Background" 
          className="w-full h-full object-cover object-right"
          referrerPolicy="no-referrer"
        />
        {/* Soft light overlay for extreme legibility - heavier on the left to cover text */}
        <div className="absolute inset-0 bg-gradient-to-r from-white via-white/90 to-white/10 md:to-transparent"></div>
      </div>

      {/* Background with new technical image - Dark Mode */}
      <div className="absolute inset-0 z-0 opacity-25 hidden dark:block">
        <img 
          src="/src/assets/images/bg_capabilities_1779874393037.png" 
          alt="Dark Industrial Blueprint Background" 
          className="w-full h-full object-cover object-right"
          referrerPolicy="no-referrer"
        />
        {/* Soft dark overlay for high contrast legibility */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0d14] via-[#0a0d14]/95 to-[#0a0d14]/30 md:to-transparent"></div>
      </div>

      <div className="section-container relative z-10 w-full">
        <div className="max-w-2xl">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-5xl md:text-7xl font-bold text-brand-charcoal dark:text-white mb-6 leading-tight">
              Engineering Solutions <br /> 
              <span className="text-brand-steel dark:text-sky-400">That Power Industry</span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-slate-300 mb-10 leading-relaxed font-light">
              MKAY Engineering delivers world-class steel fabrication, structural engineering, 
              and plant maintenance services across Zimbabwe. Excellence in every weld.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <motion.a 
                href="#services" 
                className={`btn-primary flex items-center justify-center gap-2 transition-all duration-300 dark:bg-sky-500 dark:text-[#0a0d14] dark:font-extrabold ${
                  isScrolled 
                    ? 'hover:!text-white hover:!border-white hover:!bg-transparent' 
                    : 'hover:bg-brand-steel/90 hover:shadow-lg dark:hover:bg-sky-400'
                }`}
                whileHover={{ gap: '1rem' }}
              >
                Our Services <ArrowRight size={18} />
              </motion.a>
              <a 
                href="#contact" 
                className={`btn-secondary transition-all duration-300 dark:border-sky-500/40 dark:text-sky-400 dark:hover:bg-sky-500/10 ${
                  isScrolled 
                    ? '!text-white !border-white hover:!text-white hover:!border-white hover:!bg-transparent dark:!text-sky-400 dark:!border-sky-500/40' 
                    : 'text-brand-steel border-brand-steel hover:bg-brand-steel hover:text-white'
                }`}
              >
                Contact Us
              </a>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Decorative element bottom fading */}
      <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-white dark:from-[#0a0d14] to-transparent"></div>
    </section>
  );
}
