/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { 
  Hammer, 
  Settings, 
  Wrench, 
  Layers,
  Truck,
  Compass
} from 'lucide-react';

export default function Services() {
  const services = [
    {
      title: 'Structural Steel Engineering',
      description: 'Design, heavy-gauge fabrication, and precision on-site erection of industrial portal frames, columns, and commercial truss systems.',
      icon: <Layers size={32} />
    },
    {
      title: 'General Welding',
      description: 'Certified, radiographic-quality welding services including high-pressure alloy pipe, structural joints, MMAW, MIG, and TIG applications.',
      icon: <Wrench size={32} />
    },
    {
      title: 'Mobile Services & Repairs',
      description: 'Rapid response mobile welding rigs fully equipped for emergency field repairs, on-site structural adjustments, and critical refitting.',
      icon: <Truck size={32} />
    },
    {
      title: 'Custom Metal Fabrication',
      description: 'Bespoke architectural and residential steelwork, from custom-designed garden swing benches and furniture to gate grilles and screens.',
      icon: <Hammer size={32} />
    },
    {
      title: 'Plant Maintenance & Overhauls',
      description: 'Total corrective mechanical and structural maintenance to maximize asset lifespans, including conveyors and wear-resistant liners.',
      icon: <Settings size={32} />
    },
    {
      title: 'CAD Design & Compliance',
      description: 'Full 3D modeling, load testing calculations, engineering drafting, and strict SANS 10162/AISC/BS design code compliance.',
      icon: <Compass size={32} />
    }
  ];

  return (
    <section id="services" className="bg-slate-50 dark:bg-[#10141d] text-brand-charcoal dark:text-white relative overflow-hidden py-24 transition-colors duration-300">
      {/* Technical blueprint background design adjusted for high-contrast light theme */}
      <div className="absolute inset-0 z-0 opacity-[0.04] dark:opacity-[0.02] pointer-events-none">
        <img 
          src="/src/assets/images/bg_capabilities_1779874393037.png" 
          alt="Technical Blueprints and Engineering Drawing Background" 
          className="w-full h-full object-cover object-center"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-100 via-white to-slate-100 dark:from-[#10141d] dark:via-transparent dark:to-[#10141d]"></div>
      </div>

      <div className="section-container relative z-10">
        <div className="text-center mb-20">
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-brand-steel dark:text-sky-400 font-display font-semibold uppercase tracking-widest text-sm mb-4 block"
          >
            Capabilities
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-4xl md:text-5xl font-bold mb-4 text-brand-charcoal dark:text-white font-display"
          >
            Full-Spectrum Engineering
          </motion.h2>
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 1 }}
            className="h-1 w-24 bg-brand-steel dark:bg-sky-500 mx-auto"
          />
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover="hover"
              className="bg-white dark:bg-[#151b26] p-10 border border-gray-100 dark:border-slate-800/80 rounded-sm hover:border-brand-steel/30 dark:hover:border-sky-500/30 hover:shadow-xl dark:hover:shadow-sky-500/5 transition-all duration-300 group relative overflow-hidden shadow-sm"
            >
              {/* Subtle technical background grid pattern for light theme */}
              <div 
                className="absolute inset-0 opacity-[0.02] group-hover:opacity-[0.06] transition-opacity duration-500 pointer-events-none block dark:hidden" 
                style={{ 
                  backgroundImage: `url("data:image/svg+xml,%3Csvg width='30' height='30' viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 30 L30 0 L0 0' fill='none' stroke='%23000000' stroke-width='0.5'/%3E%3C/svg%3E")` 
                }}
              />
              {/* Subtle tech grid background grid pattern for high contrast dark theme */}
              <div 
                className="absolute inset-0 opacity-0 dark:opacity-[0.03] dark:group-hover:opacity-[0.08] transition-opacity duration-500 pointer-events-none hidden dark:block" 
                style={{ 
                  backgroundImage: `url("data:image/svg+xml,%3Csvg width='30' height='30' viewBox='0 0 30 30' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 30 L30 0 L0 0' fill='none' stroke='%23ffffff' stroke-width='0.5'/%3E%3C/svg%3E")` 
                }}
              />
              
              {/* Radial light glowing effect */}
              <div className="absolute -top-12 -right-12 w-32 h-32 bg-brand-steel/10 dark:bg-sky-500/10 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />

              <motion.div 
                variants={{
                  hover: { rotate: 8, scale: 1.15, y: -4 }
                }}
                transition={{ type: "spring", stiffness: 300, damping: 15 }}
                className="text-brand-steel dark:text-sky-400 mb-6 inline-block origin-left"
              >
                {service.icon}
              </motion.div>
              
              <h3 className="text-2xl font-bold mb-4 z-10 relative text-brand-charcoal dark:text-white font-display">{service.title}</h3>
              <p className="text-gray-500 dark:text-slate-400 font-light leading-relaxed z-10 relative">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
