/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, MapPin, Calendar, Award, HardHat, FileCode, Hammer, Scale, ZoomIn } from 'lucide-react';

interface Project {
  title: string;
  category: string;
  location: string;
  description: string;
  image: string;
  specs: {
    client: string;
    year: string;
    tonnage: string;
    services: string;
    designCodes: string;
  };
}

export default function Projects() {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  // Prevent scroll when modal is open
  useEffect(() => {
    if (selectedProject) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [selectedProject]);

  const categories = ['All', 'General Welding', 'Structural Steel Engineering', 'Mobile Services and Repairs'];

  const projects: Project[] = [
    {
      title: 'Structural Steel Portal Frame Warehouse',
      category: 'Structural Steel Engineering',
      location: 'Belmont Industrial Area, Bulawayo',
      description: 'Design, high-load fabrication, and precise on-site erection of a large 5,000 sqm industrial portal frame warehouse structure for heavy logistics.',
      image: '/src/assets/images/structural_steel_engineering_1779288956334.png',
      specs: {
        client: 'Bulk Logistics Zimbabwe',
        year: '2025',
        tonnage: '420 Tons Structural Steel',
        services: '3D CAD Modeling, Structural Rigging and Lifting Plans, Grade 8.8 High-Tensile Bolting, Crane Erection, NSSA Inspection Approved',
        designCodes: 'SANS 10162 (Part 1) / BS 5950 / SAZ'
      }
    },
    {
      title: 'Professional Coded High-Pressure Pipe Welding',
      category: 'General Welding',
      location: 'Msasa Industrial Area, Harare',
      description: 'Precision multi-alloy steam line welding and high-pressure chemical transfer pipelines with 100% radiographic check approvals.',
      image: '/src/assets/images/general_welding_1779288978155.png',
      specs: {
        client: 'Zimbabwe Phosphate Industries (ZimPhos)',
        year: '2026',
        tonnage: 'High-Temp Ammonia Feed Lines',
        services: 'Gas Tungsten Arc Welding (GTAW), Shielded Metal Arc Welding (SMAW), NDT Radiographic Certification, Msasa Plant On-site Alignments',
        designCodes: 'AWS D1.1 / ASME Section IX / SAZ Standards'
      }
    },
    {
      title: 'Architectural Polycarbonate & Wrought-Iron Work',
      category: 'Mobile Services and Repairs',
      location: 'Vumba Mountains, Mutare',
      description: 'Custom bespoke ironmongery gates, structural garden swings, and robust translucent polycarbonate shelters designed to withstand damp, high-humidity mountain climates.',
      image: '/src/assets/images/mobile_services_and_repairs_1779289002630.png',
      specs: {
        client: 'Vumba Heights Estate & Leisure Resort',
        year: '2026',
        tonnage: 'Bespoke Structural Metalwork',
        services: 'Handcrafted black scrollwork, mobile onsite arc-welding repairs, anti-corrosive primer systems, translucent polycarbonate shelter frames',
        designCodes: 'ASTM Structural Standards & Custom Architectural Specs'
      }
    }
  ];

  const filteredProjects = activeCategory === 'All' 
    ? projects 
    : projects.filter(p => p.category === activeCategory);

  return (
    <section id="projects" className="bg-gray-50 dark:bg-[#0a0d14] relative overflow-hidden transition-colors duration-300">
      {/* Dynamic structural background element in light mode */}
      <div className="absolute inset-0 opacity-[0.02] pointer-events-none block dark:hidden" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 40 L40 0' fill='none' stroke='%23000000' stroke-width='0.5'/%3E%3C/svg%3E")` }}></div>
      {/* Dynamic structural background element in dark mode */}
      <div className="absolute inset-0 opacity-[0.03] pointer-events-none hidden dark:block" style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 40 L40 0' fill='none' stroke='%23ffffff' stroke-width='0.5'/%3E%3C/svg%3E")` }}></div>
      
      <div className="section-container relative z-10">
        {/* Header Block */}
        <div className="flex flex-col xl:flex-row justify-between items-start xl:items-end mb-16 gap-8">
          <div className="max-w-2xl">
            <span className="text-brand-steel dark:text-sky-400 font-display font-semibold uppercase tracking-widest text-sm mb-4 block">
              Our Heavy Portfolio
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-2 text-brand-charcoal dark:text-white">Featured Projects</h2>
            <p className="text-gray-500 dark:text-slate-400 font-light mt-3">
              Explore our landmark heavy steel endeavors, mechanical erection works, and plant maintenance operations successfully delivered throughout Zimbabwe. Click any project to inspect its rigorous engineering specifications.
            </p>
          </div>
          
          {/* Quick Stats Banner */}
          <div className="flex gap-6 py-4 px-6 bg-white dark:bg-[#151b26] border border-gray-100 dark:border-slate-800/80 rounded-sm shadow-sm transition-colors duration-300">
            <div className="border-r border-gray-200 dark:border-slate-800 pr-6">
              <span className="block font-display font-extrabold text-2xl text-brand-steel dark:text-sky-400">2,300+</span>
              <span className="text-[10px] uppercase font-mono tracking-wider text-gray-400 dark:text-slate-500">Tons Erected</span>
            </div>
            <div>
              <span className="block font-display font-extrabold text-2xl text-brand-steel dark:text-sky-400">100%</span>
              <span className="text-[10px] uppercase font-mono tracking-wider text-gray-400 dark:text-slate-500">Load Compliant</span>
            </div>
          </div>
        </div>

        {/* Categories Tab Bar */}
        <div className="flex flex-wrap gap-2 mb-12 border-b border-gray-200/60 dark:border-slate-800/80 pb-6">
          {categories.map((cat) => (
            <button
              key={cat}
              id={`tab-${cat.toLowerCase().replace(/\s+/g, '-')}`}
              onClick={() => setActiveCategory(cat)}
              className={`relative px-5 py-2 text-xs font-bold uppercase tracking-wider transition-all rounded-full ${
                activeCategory === cat 
                  ? 'text-white bg-brand-steel dark:bg-sky-500 dark:text-[#0a0d14] shadow-sm font-semibold' 
                  : 'text-gray-500 hover:text-brand-charcoal dark:hover:text-white hover:bg-gray-100/80 dark:hover:bg-slate-800/50 bg-transparent'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <motion.div 
          layout
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence mode="popLayout">
            {filteredProjects.map((project, index) => (
              <motion.div
                key={project.title}
                id={`project-card-${index}`}
                layout
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.4, ease: 'easeOut' }}
                whileHover="hover"
                onClick={() => setSelectedProject(project)}
                className="group cursor-pointer bg-white dark:bg-[#151b26] border border-gray-100 dark:border-slate-800/80 p-4 rounded-sm shadow-sm hover:shadow-xl dark:hover:shadow-sky-500/5 hover:border-brand-steel/30 dark:hover:border-sky-500/30 transition-all duration-300"
              >
                {/* Image Container with precise overlay */}
                <div className="relative overflow-hidden rounded-sm mb-5 aspect-video bg-gray-100 dark:bg-slate-900">
                  <motion.div 
                    variants={{
                      hover: { opacity: 1 }
                    }}
                    transition={{ duration: 0.3 }}
                    className="absolute inset-0 bg-brand-charcoal/30 opacity-0 z-10 flex items-center justify-center pointer-events-none" 
                  >
                    <div className="bg-white/90 dark:bg-slate-900/95 text-brand-charcoal dark:text-white rounded-full p-3 shadow-md border dark:border-slate-800">
                      <ZoomIn size={18} className="text-brand-steel dark:text-sky-400" />
                    </div>
                  </motion.div>
                  
                  <motion.img 
                    src={project.image} 
                    alt={project.title} 
                    variants={{
                      hover: { scale: 1.06 }
                    }}
                    transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                    className="w-full h-full object-cover" 
                  />
                  
                  <div className="absolute top-3 left-3 z-10 bg-brand-charcoal/85 dark:bg-[#0a0d14]/90 backdrop-blur-sm text-[10px] text-white dark:text-sky-400 font-mono uppercase font-semibold px-2.5 py-1 tracking-wider rounded-sm border dark:border-sky-500/10">
                    {project.category}
                  </div>
                </div>

                {/* Info Text Block */}
                <div>
                  <div className="flex items-center gap-1.5 text-brand-steel dark:text-sky-400 text-xs font-mono uppercase tracking-widest mb-2 font-bold">
                    <MapPin size={12} />
                    <span>{project.location}</span>
                  </div>
                  
                  <h3 className="text-xl font-bold text-brand-charcoal dark:text-white group-hover:text-brand-steel dark:group-hover:text-sky-400 transition-colors line-clamp-1 mb-2 font-display">
                    {project.title}
                  </h3>
                  
                  <p className="text-gray-500 dark:text-slate-400 font-light text-sm line-clamp-2 leading-relaxed h-[40px]">
                    {project.description}
                  </p>
                  
                  <div className="mt-4 pt-4 border-t border-gray-100 dark:border-slate-800/80 flex items-center justify-between text-xs font-mono text-gray-400 dark:text-slate-500">
                    <span className="flex items-center gap-1"><Award size={12} className="text-brand-steel dark:text-sky-400" /> {project.specs.tonnage}</span>
                    <span className="text-brand-steel dark:text-sky-400 group-hover:translate-x-1 transition-transform duration-300 font-bold uppercase tracking-wider text-[10px]">
                      Specs Panel &rarr;
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Advanced Specifications Detail Modal Overlay */}
      <AnimatePresence>
        {selectedProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Modal Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProject(null)}
              className="absolute inset-0 bg-brand-charcoal/80 dark:bg-black/85 backdrop-blur-sm"
              id="projects-modal-backdrop"
            />
            
            {/* Modal Content Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="relative bg-white dark:bg-[#121824] w-full max-w-3xl rounded-sm shadow-2xl overflow-hidden border border-gray-100 dark:border-slate-800 max-h-[90vh] flex flex-col z-10"
              id="projects-modal-card"
            >
              {/* Image Banner */}
              <div className="relative h-64 sm:h-80 w-full overflow-hidden shrink-0">
                <img 
                  src={selectedProject.image} 
                  alt={selectedProject.title} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />
                
                {/* Close Button */}
                <button
                  id="close-project-modal"
                  onClick={() => setSelectedProject(null)}
                  className="absolute top-4 right-4 bg-brand-charcoal/70 hover:bg-black text-white p-2.5 rounded-full transition-colors z-20 border border-white/10"
                  aria-label="Close specs details"
                >
                  <X size={20} />
                </button>

                {/* Banner Text overlay */}
                <div className="absolute bottom-5 left-6 right-6">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span className="bg-brand-steel/90 dark:bg-sky-500 text-white dark:text-[#0a0d14] font-mono text-[9px] uppercase tracking-widest px-2.5 py-0.5 font-bold rounded-sm">
                      {selectedProject.category}
                    </span>
                    <span className="bg-white/20 text-white font-mono text-[9px] uppercase tracking-widest px-2.5 py-0.5 rounded-sm flex items-center gap-1">
                      <MapPin size={10} /> {selectedProject.location}
                    </span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
                    {selectedProject.title}
                  </h3>
                </div>
              </div>

              {/* Specs Grid and Technical Description Body */}
              <div className="p-6 sm:p-8 overflow-y-auto flex-1">
                <div className="grid sm:grid-cols-2 gap-8 mb-8">
                  {/* Scope of Work Column */}
                  <div>
                    <h4 className="text-xs uppercase tracking-widest font-mono font-bold text-gray-400 dark:text-slate-500 mb-3 flex items-center gap-1.5">
                      <CommandLineIcon /> Scope & Details
                    </h4>
                    <p className="text-gray-600 dark:text-slate-300 text-sm leading-relaxed font-light mb-4">
                      {selectedProject.description}
                    </p>
                    <div className="bg-gray-50 dark:bg-[#151b26] p-4 border border-gray-100 dark:border-slate-800/80 rounded-sm">
                      <span className="block font-mono text-[10px] uppercase font-bold text-brand-steel dark:text-sky-400 mb-1">
                        High-End Delivered Services
                      </span>
                      <p className="text-xs text-gray-500 dark:text-slate-400 leading-relaxed font-light font-mono">
                        {selectedProject.specs.services}
                      </p>
                    </div>
                  </div>

                  {/* Technical Specifications Blueprint Grid */}
                  <div className="space-y-4">
                    <h4 className="text-xs uppercase tracking-widest font-mono font-bold text-gray-400 dark:text-slate-500 mb-3">
                      Rigorous Specifications
                    </h4>
                    <div className="border border-brand-silver dark:border-slate-800/80 bg-gray-50/50 dark:bg-[#151b26]/30 p-4 font-mono text-xs rounded-sm space-y-3.5">
                      <div className="flex justify-between items-center border-b border-gray-200/50 dark:border-slate-800/50 pb-2">
                        <span className="text-gray-400 dark:text-slate-500 flex items-center gap-1.5"><Calendar size={13} /> Project Year</span>
                        <span className="font-bold text-brand-charcoal dark:text-white">{selectedProject.specs.year}</span>
                      </div>
                      
                      <div className="flex justify-between items-center border-b border-gray-200/50 dark:border-slate-800/50 pb-2">
                        <span className="text-gray-400 dark:text-slate-500 flex items-center gap-1.5"><Scale size={13} /> Steel Mass</span>
                        <span className="font-bold text-brand-steel dark:text-sky-400">{selectedProject.specs.tonnage}</span>
                      </div>

                      <div className="flex justify-between items-center border-b border-gray-200/50 dark:border-slate-800/50 pb-2">
                        <span className="text-gray-400 dark:text-slate-500 flex items-center gap-1.5"><HardHat size={13} /> Principal Client</span>
                        <span className="font-bold text-brand-charcoal dark:text-white text-right text-[11px] leading-tight max-w-[200px]">{selectedProject.specs.client}</span>
                      </div>

                      <div className="flex justify-between items-center pt-1">
                        <span className="text-gray-400 dark:text-slate-500 flex items-center gap-1.5"><FileCode size={13} /> Design Standards</span>
                        <span className="font-bold text-brand-steel dark:text-sky-400 text-[10px] bg-brand-steel/5 dark:bg-sky-500/10 text-brand-steel px-2 py-0.5 rounded-sm">{selectedProject.specs.designCodes}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end gap-3 border-t border-gray-100 dark:border-slate-800/80 pt-6">
                  <button
                    id="modal-request-consultation"
                    onClick={() => {
                      setSelectedProject(null);
                      window.location.href = "#contact";
                    }}
                    className="bg-brand-steel dark:bg-sky-500 hover:bg-brand-steel/95 dark:hover:bg-sky-400 text-white dark:text-[#0a0d14] dark:font-extrabold text-xs uppercase tracking-wider font-bold py-3 px-6 rounded-sm transition-all shadow-sm"
                  >
                    Discuss Similar Project
                  </button>
                  <button
                    id="modal-close-btn"
                    onClick={() => setSelectedProject(null)}
                    className="bg-gray-100 dark:bg-slate-800 hover:bg-gray-200 dark:hover:bg-slate-700 text-brand-charcoal dark:text-white text-xs uppercase tracking-wider font-bold py-3 px-5 rounded-sm transition-all"
                  >
                    Close Specs
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}

// Extra local SVG icon to prevent extra import dependencies
function CommandLineIcon() {
  return (
    <svg className="w-3.5 h-3.5 text-brand-steel fill-none stroke-current" viewBox="0 0 24 24" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="4 17 10 11 4 5" />
      <line x1="12" y1="19" x2="20" y2="19" />
    </svg>
  );
}

