/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent, ChangeEvent } from 'react';
import { motion } from 'motion/react';
import { Phone, Mail, MapPin, Send, CheckCircle, Clock } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: '',
    projectType: 'Steel Fabrication',
    message: ''
  });

  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const validate = () => {
    const newErrors: { [key: string]: string } = {};
    
    if (!formData.fullName.trim()) {
      newErrors.fullName = 'Full name is required';
    } else if (formData.fullName.trim().length < 2) {
      newErrors.fullName = 'Name must be at least 2 characters';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      newErrors.email = 'Email address is required';
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Phone number is required';
    }

    if (!formData.message.trim()) {
      newErrors.message = 'Please provide details about your project';
    } else if (formData.message.trim().length < 10) {
      newErrors.message = 'Message must be at least 10 characters';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!validate()) return;

    setIsSubmitting(true);
    
    try {
      const formattedMessage = `Hello MKAY Engineering,\n\n*Name:* ${formData.fullName}\n*Phone:* ${formData.phone}\n*Email:* ${formData.email}\n*Sector/Project:* ${formData.projectType}\n\n*Message:*\n${formData.message}`;
      const codedText = encodeURIComponent(formattedMessage);
      const whatsappUrl = `https://wa.me/263784723205?text=${codedText}`;
      
      // Try opening in a new tab first. If blocked by the browser inside the viewport iframe, redirect the current window securely.
      const newWindow = window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
      if (!newWindow) {
        window.location.href = whatsappUrl;
      }

      setIsSuccess(true);
      setFormData({
        fullName: '',
        email: '',
        phone: '',
        projectType: 'Steel Fabrication',
        message: ''
      });
      setTimeout(() => setIsSuccess(false), 5000);
    } catch (error) {
      console.error('Submission error:', error);
      setErrors({ form: 'Something went wrong. Please try again later.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };
  return (
    <section id="contact" className="relative overflow-hidden py-24 bg-white dark:bg-[#0a0d14] text-brand-charcoal dark:text-white transition-colors duration-300">
      {/* Background image representing the gray concrete desk with blueprints and yellow hard hat */}
      <div className="absolute inset-0 z-0 opacity-25 pointer-events-none block dark:hidden">
        <img 
          src="/src/assets/images/bg_blueprint_hardhat_1779874177088.png" 
          alt="Drafting Table and Blueprints Background" 
          className="w-full h-full object-cover object-left"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-white/95 via-white/90 to-white/95"></div>
      </div>
      
      {/* Dark Mode Background layout */}
      <div className="absolute inset-0 z-0 opacity-[0.06] pointer-events-none hidden dark:block">
        <img 
          src="/src/assets/images/bg_architect_blueprint_1779874197353.png" 
          alt="Drafting Table & Blueprints Dark Filter" 
          className="w-full h-full object-cover object-left filter invert-[0.8]"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0a0d14]/95 via-[#0a0d14]/90 to-[#0a0d14]/95"></div>
      </div>
      
      <div className="section-container relative z-10">
        <div className="grid lg:grid-cols-2 gap-20">
          <div>
            <span className="text-brand-steel dark:text-sky-400 font-display font-semibold uppercase tracking-widest text-sm mb-4 block">
              Contact Us
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-8 text-brand-charcoal dark:text-white">Start Your Next <br /> Scale Engineering Project</h2>
            <p className="text-lg text-gray-600 dark:text-slate-300 mb-12 italic">
              Have a complex engineering challenge? Our team of experts is ready to discuss your requirements 
              and provide a tailored solution.
            </p>

            <div className="space-y-8">
              {[
                { icon: <Phone size={24} />, label: 'Call Us / WhatsApp', value: '+263 78 472 3205' },
                { icon: <Mail size={24} />, label: 'Email', value: 'bensonmkunguma002@gmail.com' },
                { icon: <MapPin size={24} />, label: 'Location', value: 'Plot 2 Greenhills, Tynwald South, Harare, Zimbabwe' },
                { icon: <Clock size={24} />, label: 'Business hours', value: 'Sunday - Friday (Strictly Closed on Sabbath)' },
              ].map((item) => (
                <div key={item.label} className="flex items-start gap-5">
                  <div className="w-12 h-12 bg-gray-50 dark:bg-[#151b26] flex items-center justify-center rounded-sm text-brand-steel dark:text-sky-400 border dark:border-slate-800">
                    {item.icon}
                  </div>
                  <div>
                    <span className="text-xs uppercase tracking-widest text-gray-400 dark:text-slate-500 font-bold block mb-1">
                      {item.label}
                    </span>
                    <span className="text-lg font-medium text-brand-charcoal dark:text-white">{item.value}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.98 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="bg-gray-50 dark:bg-[#121822] p-10 rounded-sm border border-gray-100 dark:border-slate-800/80 relative"
          >
            {isSuccess && (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="absolute inset-0 z-10 bg-gray-50 dark:bg-[#121822] flex flex-col items-center justify-center p-10 text-center"
              >
                <CheckCircle size={64} className="text-green-500 mb-4" />
                <h3 className="text-2xl font-bold mb-2 text-brand-charcoal dark:text-white">Message Sent!</h3>
                <p className="text-gray-600 dark:text-slate-300 italic">Thank you for reaching out. Our engineering team will contact you shortly.</p>
              </motion.div>
            )}
            
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs uppercase tracking-widest font-bold text-gray-400 dark:text-slate-400 mb-2">FullName</label>
                  <input 
                    name="fullName"
                    type="text" 
                    value={formData.fullName}
                    onChange={handleChange}
                    placeholder="John Doe"
                    className={`w-full px-4 py-3 bg-white dark:bg-[#151b26] border ${errors.fullName ? 'border-red-500' : 'border-gray-200 dark:border-slate-800'} focus:border-brand-steel dark:focus:border-sky-500 focus:outline-none transition-all rounded-sm italic text-brand-charcoal dark:text-white`}
                  />
                  {errors.fullName && <p className="text-red-500 text-[10px] uppercase font-bold mt-1 tracking-wider">{errors.fullName}</p>}
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-widest font-bold text-gray-400 dark:text-slate-400 mb-2">Email Address</label>
                  <input 
                    name="email"
                    type="email" 
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="john@company.com"
                    className={`w-full px-4 py-3 bg-white dark:bg-[#151b26] border ${errors.email ? 'border-red-500' : 'border-gray-200 dark:border-slate-800'} focus:border-brand-steel dark:focus:border-sky-500 focus:outline-none transition-all rounded-sm italic text-brand-charcoal dark:text-white`}
                  />
                  {errors.email && <p className="text-red-500 text-[10px] uppercase font-bold mt-1 tracking-wider">{errors.email}</p>}
                </div>
              </div>
              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs uppercase tracking-widest font-bold text-gray-400 dark:text-slate-400 mb-2">Phone Number</label>
                  <input 
                    name="phone"
                    type="text" 
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+263 78 472 3205"
                    className={`w-full px-4 py-3 bg-white dark:bg-[#151b26] border ${errors.phone ? 'border-red-500' : 'border-gray-200 dark:border-slate-800'} focus:border-brand-steel dark:focus:border-sky-500 focus:outline-none transition-all rounded-sm italic text-brand-charcoal dark:text-white`}
                  />
                  {errors.phone && <p className="text-red-500 text-[10px] uppercase font-bold mt-1 tracking-wider">{errors.phone}</p>}
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-widest font-bold text-gray-400 dark:text-slate-400 mb-2">Project Type</label>
                  <div className="relative">
                    <select 
                      name="projectType"
                      value={formData.projectType}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-white dark:bg-[#151b26] border border-gray-200 dark:border-slate-800 focus:border-brand-steel dark:focus:border-sky-500 focus:outline-none transition-all rounded-sm italic appearance-none text-brand-charcoal dark:text-white"
                    >
                      <option className="bg-white dark:bg-[#151b26] text-brand-charcoal dark:text-white">Steel Fabrication</option>
                      <option className="bg-white dark:bg-[#151b26] text-brand-charcoal dark:text-white">Structural Engineering</option>
                      <option className="bg-white dark:bg-[#151b26] text-brand-charcoal dark:text-white">Plant Maintenance</option>
                      <option className="bg-white dark:bg-[#151b26] text-brand-charcoal dark:text-white">Other Services</option>
                    </select>
                    <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-gray-500 dark:text-slate-400">
                      <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20">
                        <path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
              <div>
                <label className="block text-xs uppercase tracking-widest font-bold text-gray-400 dark:text-slate-400 mb-2">Message</label>
                <textarea 
                  name="message"
                  rows={5}
                  value={formData.message}
                  onChange={handleChange}
                  placeholder="How can we help you?"
                  className={`w-full px-4 py-3 bg-white dark:bg-[#151b26] border ${errors.message ? 'border-red-500' : 'border-gray-200 dark:border-slate-800'} focus:border-brand-steel dark:focus:border-sky-500 focus:outline-none transition-all rounded-sm italic text-brand-charcoal dark:text-white`}
                ></textarea>
                {errors.message && <p className="text-red-500 text-[10px] uppercase font-bold mt-1 tracking-wider">{errors.message}</p>}
              </div>
              
              {errors.form && <p className="text-red-500 text-sm font-medium italic text-center">{errors.form}</p>}
              
              <button 
                type="submit" 
                disabled={isSubmitting}
                className={`btn-primary w-full flex items-center justify-center gap-2 group dark:bg-sky-500 dark:text-[#0a0d14] dark:font-extrabold dark:hover:bg-sky-400 ${isSubmitting ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {isSubmitting ? (
                  <span className="flex items-center gap-2">
                    Processing...
                    <motion.div 
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full"
                    />
                  </span>
                ) : (
                  <>Send Message <Send size={18} className="group-hover:translate-x-1 transition-transform" /></>
                )}
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
