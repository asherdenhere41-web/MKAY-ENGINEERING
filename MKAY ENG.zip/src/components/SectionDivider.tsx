/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { motion } from 'motion/react';

interface SectionDividerProps {
  type?: 'line' | 'gradient' | 'pattern';
  className?: string;
}

export default function SectionDivider({ type = 'line', className = '' }: SectionDividerProps) {
  if (type === 'gradient') {
    return (
      <div className={`w-full overflow-hidden ${className}`}>
        <motion.div
          animate={{
            backgroundPosition: ['0% 50%', '100% 50%', '0% 50%'],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="h-px w-full bg-gradient-to-r from-transparent via-brand-steel/30 to-transparent bg-[length:200%_auto]"
        />
      </div>
    );
  }

  if (type === 'pattern') {
    return (
      <div className={`w-full py-4 overflow-hidden opacity-10 ${className}`}>
         <motion.div 
            animate={{ x: [0, -60] }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="h-2 w-[120%] bg-repeat-x"
            style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='8' viewBox='0 0 60 8' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M0 4 L10 0 L20 4 L30 0 L40 4 L50 0 L60 4' fill='none' stroke='%232b4b7a' stroke-width='1'/%3E%3C/svg%3E")` }}
         />
      </div>
    );
  }

  return (
    <div className={`section-container py-0 ${className}`}>
      <motion.div 
        initial={{ scaleX: 0, opacity: 0 }}
        whileInView={{ scaleX: 1, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1.5, ease: "circOut" }}
        className="h-px bg-gray-100 w-full origin-left"
      />
    </div>
  );
}
