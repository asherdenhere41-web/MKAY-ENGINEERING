/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence, useScroll, useMotionValueEvent } from 'motion/react';
import { Menu, X, ChevronRight, Sun, Moon } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

export default function Navbar() {
  const { theme, toggleTheme } = useTheme();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isHidden, setIsHidden] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { scrollY, scrollYProgress } = useScroll();

  useMotionValueEvent(scrollY, "change", (latest) => {
    const previous = scrollY.getPrevious() ?? 0;
    if (latest > previous && latest > 150) {
      setIsHidden(true);
    } else {
      setIsHidden(false);
    }
    setIsScrolled(latest > 50);
  });

  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Services', href: '#services' },
    { name: 'Projects', href: '#projects' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <motion.nav 
      id="main-nav"
      variants={{
        visible: { y: 0 },
        hidden: { y: '-100%' },
      }}
      animate={isHidden ? 'hidden' : 'visible'}
      transition={{ duration: 0.35, ease: 'easeInOut' }}
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
        isScrolled 
          ? 'bg-white/90 border-b border-gray-100 dark:bg-[#0a0d14]/90 dark:border-slate-800/80 backdrop-blur-md shadow-sm py-3' 
          : 'bg-transparent py-6'
      }`}
    >
      {/* Scroll Progress Bar */}
      <motion.div 
        className="absolute top-0 left-0 h-[3px] bg-brand-steel dark:bg-sky-500 z-[60]"
        style={{ 
          scaleX: scrollYProgress,
          transformOrigin: '0%' 
        }}
      />

      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center bg-transparent">
        <a href="#" className="flex items-center gap-3 group">
          <motion.div 
            whileHover={{ scale: 1.05 }}
            className="w-10 h-10 bg-brand-steel dark:bg-sky-950/80 flex items-center justify-center rounded-sm shadow-lg shadow-brand-steel/20 border dark:border-sky-500/30"
          >
            <span className="text-white dark:text-sky-400 font-display font-bold text-xl">MK</span>
          </motion.div>
          <div className="flex flex-col -gap-1">
            <span className="font-display font-bold text-xl tracking-tighter leading-none text-brand-charcoal dark:text-white">
              MKAY
            </span>
            <span className="font-mono text-[10px] tracking-[0.3em] font-bold text-brand-charcoal/60 dark:text-slate-400">
              ENGINEERING
            </span>
          </div>
        </a>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-10">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href}
              className="text-xs font-bold uppercase tracking-[0.2em] transition-all relative group text-brand-charcoal dark:text-slate-300 hover:text-brand-steel dark:hover:text-sky-400"
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-[2px] bg-brand-steel dark:bg-sky-500 transition-all group-hover:w-full"></span>
            </a>
          ))}
          
          {/* Theme Slider Toggle for Desktop */}
          <button
            onClick={toggleTheme}
            id="desktop-theme-switcher"
            className="p-2.5 rounded-sm border border-gray-200 hover:border-brand-steel dark:border-slate-800 dark:hover:border-sky-500 text-brand-charcoal dark:text-slate-300 bg-white/20 dark:bg-black/20 hover:bg-gray-50/50 dark:hover:bg-slate-900/50 transition-all flex items-center justify-center"
            title={theme === 'light' ? 'Switch to Industrial Dark Theme' : 'Switch to Clean Light Theme'}
          >
            {theme === 'light' ? (
              <Moon size={16} className="text-brand-steel" />
            ) : (
              <Sun size={16} className="text-sky-400" />
            )}
          </button>

          <motion.a 
            href="#contact" 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className={`px-6 py-2.5 text-xs font-bold uppercase tracking-[0.15em] border-2 transition-all duration-300 ${
              isScrolled 
                ? 'border-brand-steel bg-brand-steel text-white hover:bg-transparent hover:text-brand-steel dark:border-sky-500 dark:bg-sky-500 dark:text-[#0a0d14] dark:hover:bg-transparent dark:hover:text-sky-400' 
                : 'border-brand-steel text-brand-steel hover:bg-brand-steel hover:text-white dark:border-sky-500 dark:text-sky-400 dark:hover:bg-sky-500 dark:hover:text-[#0a0d14]'
            }`}
          >
            Consultation
          </motion.a>
        </div>

        {/* Mobile Toggle & Theme Switcher */}
        <div className="flex md:hidden items-center gap-3">
          <button
            onClick={toggleTheme}
            id="mobile-theme-switcher"
            className="p-2 sm:p-2.5 rounded-sm border border-gray-100 dark:border-slate-800 text-brand-charcoal dark:text-slate-300 bg-white/10 dark:bg-black/10"
            aria-label="Toggle Theme"
          >
            {theme === 'light' ? (
              <Moon size={16} className="text-brand-steel" />
            ) : (
              <Sun size={16} className="text-sky-400" />
            )}
          </button>
          
          <button 
            className="p-2 text-brand-charcoal dark:text-white"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            aria-label="Toggle Menu"
          >
            {isMobileMenuOpen ? (
              <X className="text-brand-charcoal dark:text-white" size={28} />
            ) : (
              <Menu className="text-brand-charcoal dark:text-white" size={28} />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 top-[60px] md:hidden bg-white dark:bg-[#0a0d14] z-40 overflow-hidden"
          >
            <div className="flex flex-col p-8 gap-8 h-full bg-white dark:bg-[#0a0d14]">
              {navLinks.map((link, i) => (
                <motion.a 
                  key={link.name} 
                  href={link.href}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="text-brand-charcoal dark:text-white text-2xl font-display font-bold border-b border-gray-100 dark:border-slate-800/80 pb-4 flex justify-between items-center"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {link.name}
                  <ChevronRight size={24} className="text-gray-300 dark:text-slate-600" />
                </motion.a>
              ))}
              <motion.a 
                href="#contact" 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="btn-primary dark:bg-sky-500 dark:text-[#0a0d14] dark:font-extrabold py-5 text-center mt-auto mb-10"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Start a Project
              </motion.a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}
