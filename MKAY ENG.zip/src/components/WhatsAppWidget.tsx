/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import { motion, AnimatePresence } from 'motion/react';
import { MessageCircle, X, Send } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function WhatsAppWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [showTooltip, setShowTooltip] = useState(false);

  // Show tooltip after a delay
  useEffect(() => {
    const timer = setTimeout(() => setShowTooltip(true), 5000);
    return () => clearTimeout(timer);
  }, []);

  const phoneNumber = "263784723205"; // Coded local business number
  const message = "Hello MKAY Engineering team, I'm interested in a consultation for a project.";
  const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(message)}`;

  return (
    <div className="fixed bottom-8 right-8 z-50 flex flex-col items-end">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9, originX: 1, originY: 1 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="mb-4 w-72 bg-white rounded-xl shadow-2xl overflow-hidden border border-gray-100"
          >
            {/* Header */}
            <div className="bg-[#25D366] p-4 text-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-white/20 flex items-center justify-center font-bold text-xl">
                  M
                </div>
                <div>
                  <h4 className="font-bold text-sm">MKAY Support</h4>
                  <p className="text-[10px] opacity-90 italic">Typically replies within an hour</p>
                </div>
                <button 
                  onClick={() => setIsOpen(false)}
                  className="ml-auto hover:bg-white/10 p-1 rounded-full transition-colors"
                >
                  <X size={18} />
                </button>
              </div>
            </div>

            {/* Body */}
            <div className="p-4 bg-[#e5ddd5] min-h-[100px] flex flex-col gap-2">
              <div className="bg-white p-3 rounded-lg rounded-tl-none shadow-sm text-xs text-gray-700 max-w-[90%]">
                Hi there! 👋 <br />
                Need expert engineering advice? We're online and ready to help.
              </div>
              <div className="bg-white p-3 rounded-lg rounded-tr-none shadow-sm text-xs text-gray-700 max-w-[90%] self-end bg-[#dcf8c6]">
                I'm looking for a quote on a steel fabrication project.
              </div>
            </div>

            {/* Footer / CTA */}
            <div className="p-3 bg-white border-t">
              <a 
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 w-full py-2 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-full text-xs font-bold transition-colors uppercase tracking-widest"
              >
                Start Chat <Send size={14} />
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Floating Button */}
      <div className="relative">
        <AnimatePresence>
          {showTooltip && !isOpen && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="absolute right-full mr-4 top-1/2 -translate-y-1/2 bg-white px-4 py-2 rounded-lg shadow-lg border border-gray-100 whitespace-nowrap hidden sm:block"
            >
              <p className="text-xs font-bold text-brand-charcoal">Chat with an Engineer</p>
              <div className="absolute top-1/2 -right-2 -translate-y-1/2 w-4 h-4 bg-white rotate-45 border-r border-t border-gray-100" />
            </motion.div>
          )}
        </AnimatePresence>

        <motion.button
          onClick={() => {
            setIsOpen(!isOpen);
            setShowTooltip(false);
          }}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          className={`w-14 h-14 rounded-full flex items-center justify-center text-white shadow-2xl transition-colors ${isOpen ? 'bg-brand-charcoal' : 'bg-[#25D366]'}`}
        >
          {isOpen ? <X size={28} /> : <MessageCircle size={28} />}
          
          {/* Notification Badge */}
          {!isOpen && (
            <span className="absolute top-0 right-0 w-4 h-4 bg-red-500 border-2 border-white rounded-full animate-pulse" />
          )}
        </motion.button>
      </div>
    </div>
  );
}
