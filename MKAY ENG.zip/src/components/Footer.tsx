/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Facebook, Twitter, Linkedin, Instagram, ArrowUp } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-brand-charcoal text-white pt-24 pb-12 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-16 mb-20">
          <div className="lg:col-span-1">
            <a href="#" className="flex items-center gap-2 mb-8">
              <div className="w-10 h-10 bg-brand-steel dark:bg-sky-500 flex items-center justify-center rounded-sm">
                <span className="text-white dark:text-[#0a0d14] font-display font-bold text-xl">MK</span>
              </div>
              <span className="font-display font-bold text-xl tracking-tighter">ENGINEERING</span>
            </a>
            <p className="text-gray-400 leading-relaxed mb-6 italic">
              Empowering Zimbabwean industries through high-precision engineering and structural 
              fabrication. Professionalism in every project.
            </p>
            <p className="text-xs text-slate-400 mb-8 leading-relaxed font-mono">
              Plot 2 Greenhills, Tynwald South, Harare<br />
              Closed on Sabbath (Saturdays)
            </p>
            <div className="flex gap-4">
              {[Facebook, Twitter, Linkedin, Instagram].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 border border-white/10 rounded-full flex items-center justify-center hover:bg-brand-steel dark:hover:bg-sky-500 hover:border-brand-steel dark:hover:border-sky-500 dark:hover:text-[#0a0d14] transition-all">
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-display font-bold text-lg mb-8 uppercase tracking-widest text-brand-steel dark:text-sky-400">Services</h4>
            <ul className="space-y-4 text-gray-400 italic">
              <li><a href="#services" className="hover:text-white transition-colors">Steel Fabrication</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Structural Designs</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Welding & Machining</a></li>
              <li><a href="#services" className="hover:text-white transition-colors">Plant Overhauls</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-bold text-lg mb-8 uppercase tracking-widest text-brand-steel dark:text-sky-400">Company</h4>
            <ul className="space-y-4 text-gray-400 italic">
              <li><a href="#about" className="hover:text-white transition-colors">About MKAY</a></li>
              <li><a href="#projects" className="hover:text-white transition-colors">Recent Projects</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-bold text-lg mb-8 uppercase tracking-widest text-brand-steel dark:text-sky-400">Newsletter</h4>
            <p className="text-gray-400 mb-6 text-sm italic">Stay updated with our latest industrial projects and insights.</p>
            <form className="flex gap-2">
              <input 
                type="email" 
                placeholder="Your email" 
                className="bg-white/5 border border-white/10 px-4 py-3 text-sm focus:outline-none focus:border-brand-steel dark:focus:border-sky-500 rounded-sm flex-1 italic"
              />
              <button className="bg-brand-steel dark:bg-sky-500 dark:text-[#0a0d14] px-4 rounded-sm hover:opacity-90 transition-all">
                <ArrowUp size={18} className="rotate-45" />
              </button>
            </form>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-sm text-gray-500 italic">
            © {currentYear} MKAY Engineering (Pvt) Ltd. All rights reserved.
          </p>
          <div className="flex gap-8 text-xs text-gray-500 uppercase tracking-widest font-bold">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
          </div>
          <button 
            onClick={scrollToTop}
            className="w-10 h-10 border border-white/10 rounded-sm flex items-center justify-center hover:bg-white hover:text-brand-charcoal transition-all"
          >
            <ArrowUp size={20} />
          </button>
        </div>
      </div>
    </footer>
  );
}
