/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

export default function WhyChooseUs() {
  const reasons = [
    {
      title: 'Safety First (Zero-Harm HSE)',
      highlight: '0 LTI Record',
      description: 'Our absolute operational mandate. Fully aligned with National Social Security Authority (NSSA) safety directives and international OSHA standards to protect crews on-site.'
    },
    {
      title: 'High-Pressure Pipe Compliance',
      highlight: 'AWS & ASME IX',
      description: 'Coded high-pressure pipe welding for ammonia lines and fluid lines at Msasa industrial sites or Sable Chemicals. Coded under AWS D1.1 and ASME Section IX.'
    },
    {
      title: 'SAZ & SANS Approved Codes',
      highlight: 'Zim Standards',
      description: 'All structural calculations comply with structural steel frameworks SANS 10162 (Part 1 & 2), BS 5950, and Standards Association of Zimbabwe (SAZ) guidelines for regional wind-load safety.'
    },
    {
      title: 'Precision 3D Modeling & CAD',
      highlight: 'Shop Drafts',
      description: 'Detailed structural modeling and finite element analyses of gantry and warehouse trusses before shop floor fabrication at our Southerton workshop.'
    },
    {
      title: 'All-Terrain Mobile Repair Rigs',
      highlight: 'Zim Countrywide',
      description: 'Heavy duty welding vehicles equipped for prompt deployment to mining sites in Zvishavane (Mimosa), Shurugwi (Unki), Ngezi (Zimplats), and Hwange coal stations.'
    },
    {
      title: 'Turnkey Project Execution',
      highlight: 'No Plant Downtime',
      description: 'End-to-end local project management from structural shop drafting to final erection on concrete foundations, preventing expensive plant shutdowns.'
    }
  ];

  return (
    <section id="why-choose-us" className="relative text-white overflow-hidden bg-brand-charcoal py-24">
      {/* Heavy-duty steel & hard hat background */}
      <div className="absolute inset-0 z-0 opacity-80">
        <img 
          src="/src/assets/images/bg_dark_hardhat_1779874155397.png" 
          alt="Heavy Industrial Scratched Steel Background with Goggles" 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        {/* Soft elegant gradient overlay to darken and bring out text */}
        <div className="absolute inset-0 bg-gradient-to-r from-brand-charcoal via-brand-charcoal/95 to-brand-charcoal/80 md:to-brand-charcoal/50"></div>
        <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-brand-charcoal to-transparent"></div>
        <div className="absolute inset-0 bg-black/60"></div>
      </div>

      <div className="section-container relative z-10">
        <div className="grid lg:grid-cols-3 gap-16 items-start">
          
          {/* Main heading and credentials */}
          <div className="lg:col-span-1">
            <span className="text-slate-400 font-mono text-xs uppercase tracking-[0.2em] font-bold block mb-4">
              MKAY INTEGRITY & QUALITY
            </span>
            <h2 className="text-4xl md:text-5xl font-bold leading-tight mb-8 text-white font-display">
              Why Global Firms Choose MKAY
            </h2>
            <p className="text-slate-200 text-lg leading-relaxed mb-8">
              Heavy industry demands perfection. Our comprehensive quality control protocols, safety compliance, and elite execution workflows make us Zimbabwe's trusted engineering partner.
            </p>

            {/* Micro Stats & Credentials Panel */}
            <div className="border border-white/10 bg-black/40 p-6 rounded-sm space-y-4 mb-8">
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <span className="text-xs uppercase font-mono tracking-wider text-slate-400">HSE Safety Record</span>
                <span className="text-xs font-bold font-mono text-white">100% Zero LTI</span>
              </div>
              <div className="flex justify-between items-center border-b border-white/5 pb-3">
                <span className="text-xs uppercase font-mono tracking-wider text-slate-400">Radiographic Weld Pass</span>
                <span className="text-xs font-bold font-mono text-white">99.8% Perfect Fit</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-xs uppercase font-mono tracking-wider text-slate-400">Coverage</span>
                <span className="text-xs font-bold font-mono text-white">Zimbabwe Countrywide</span>
              </div>
            </div>

            <a href="#contact" className="w-full text-center px-8 py-4 bg-white text-brand-charcoal hover:bg-slate-100 rounded-sm font-bold uppercase tracking-widest text-sm transition-all inline-block shadow-md">
              Request a Quote
            </a>
          </div>

          {/* Expanded 6-Grid Reasons Area */}
          <div className="lg:col-span-2 grid md:grid-cols-2 gap-10">
            {reasons.map((reason, index) => (
              <motion.div
                key={reason.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.08 }}
                className="flex gap-4 p-5 rounded-sm border border-white/5 bg-black/20 hover:bg-black/30 transition-all duration-300"
              >
                <div className="shrink-0 mt-1">
                  <CheckCircle2 size={24} className="text-sky-400 bg-sky-400/10 rounded-full p-1 border border-sky-400/20 shadow-sm" />
                </div>
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <h3 className="text-white text-lg font-bold font-display">{reason.title}</h3>
                    <span className="text-[10px] uppercase font-mono font-bold tracking-wider text-sky-400 bg-sky-400/10 px-2 py-0.5 rounded-sm border border-sky-400/15">
                      {reason.highlight}
                    </span>
                  </div>
                  <p className="text-slate-300 leading-relaxed text-sm font-light">
                    {reason.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>

        </div>
      </div>
    </section>
  );
}
